<template>
    <div class="container">
      <h2>로그인</h2>
      <fieldset class="text-center">
        <label for="id">아이디</label>
        <input type="text" id="id" v-model="id" class="view" /><br />
        <label for="password">비밀번호</label>
        <input
          type="password"
          id="password"
          v-model="password"
          class="view"
        /><br />
        <b-button variant="success" @click="login">로그인</b-button>
      </fieldset>
    </div>
  </template>
  <script>
  export default {
    name: "LoginForm",
    data() {
      return {
        id: "",
        password: "",
      };
    },
    methods: {
      login() {
        if (
          this.id.trim === "" ||
          this.password.trim === ""
         ) {
          alert("모든 내용을 입력해주세요");
          return;
        }

        let user = {
          id: this.id,
          password: this.password,
        };
  
        this.$store.dispatch("setLoginUser", user);
      },
    },
  };
  </script>
  <style></style>
  